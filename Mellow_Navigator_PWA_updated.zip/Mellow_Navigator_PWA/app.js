// Simple client-side storage using localStorage for demonstration
function $(selector) {
  return document.querySelector(selector);
}

function loadProfile() {
  const profile = JSON.parse(localStorage.getItem('profile')) || {
    name: 'Menglu',
    diagnoses: [
      'Autism with high support needs',
      'POTS',
      'Chronic fatigue syndrome',
      'Hypermobility (suspected EDS)',
      'PTSD',
      'IBS',
      'Thyroid nodule'
    ],
    allergies: ['Benzoyl peroxide', 'Onions', 'Shellfish', 'Oysters', 'Pollen'],
    gp: 'Dr McNiff'
  };
  return profile;
}

function saveProfile(profile) {
  localStorage.setItem('profile', JSON.stringify(profile));
}

function renderProfile() {
  const profile = loadProfile();
  const container = document.getElementById('profile');
  container.innerHTML = '';
  const nameEl = document.createElement('div');
  nameEl.className = 'card';
  nameEl.innerHTML = `<div class="card-title">Name</div><div>${profile.name}</div>`;
  container.appendChild(nameEl);

  const diagEl = document.createElement('div');
  diagEl.className = 'card';
  diagEl.innerHTML = `<div class="card-title">Diagnoses</div><div>${profile.diagnoses.join(', ')}</div>`;
  container.appendChild(diagEl);

  const allergiesEl = document.createElement('div');
  allergiesEl.className = 'card';
  allergiesEl.innerHTML = `<div class="card-title">Allergies</div><div>${profile.allergies.join(', ')}</div>`;
  container.appendChild(allergiesEl);

  const gpEl = document.createElement('div');
  gpEl.className = 'card';
  gpEl.innerHTML = `<div class="card-title">GP</div><div>${profile.gp}</div>`;
  container.appendChild(gpEl);
}

function loadState() {
  const state = JSON.parse(localStorage.getItem('state')) || {
    energy: null,
    period: false,
    schedule: [],
    medications: [],
    documents: []
  };
  return state;
}

function saveState(state) {
  localStorage.setItem('state', JSON.stringify(state));
}

function updateSchedule() {
  const { schedule } = loadState();
  const list = document.getElementById('schedule-list');
  list.innerHTML = '';
  if (schedule.length === 0) {
    const empty = document.createElement('div');
    empty.textContent = 'No tasks planned yet.';
    list.appendChild(empty);
  } else {
    schedule.forEach((item) => {
      const card = document.createElement('div');
      card.className = 'card';
      card.innerHTML = `<div class="card-title">${item.title}</div><div>${item.time}</div>`;
      list.appendChild(card);
    });
  }
}

function updateMedications() {
  const { medications } = loadState();
  const list = document.getElementById('medication-list');
  list.innerHTML = '';
  if (medications.length === 0) {
    const empty = document.createElement('div');
    empty.textContent = 'No medication entries yet.';
    list.appendChild(empty);
  } else {
    medications.forEach((item) => {
      const card = document.createElement('div');
      card.className = 'card';
      card.innerHTML = `<div class="card-title">${item.name}</div><div>${item.time} - ${item.dose}</div>`;
      list.appendChild(card);
    });
  }
}

function handleEnergySelection(value) {
  const state = loadState();
  state.energy = value;
  saveState(state);
  document.querySelectorAll('.energy-btn').forEach((btn) => {
    btn.classList.remove('selected');
    if (btn.dataset.value === value) btn.classList.add('selected');
  });
  // generate simple schedule based on energy
  generateSchedule();
}

function generateSchedule() {
  const state = loadState();
  const energy = state.energy;
  const period = state.period;
  // simple example schedule; can be expanded
  const schedules = {
    low: [
      { title: 'Rest and hydration', time: 'Morning' },
      { title: 'Light stretch', time: 'Afternoon' },
      { title: 'Early bed', time: 'Evening' }
    ],
    medium: [
      { title: 'Medication', time: 'Morning' },
      { title: 'Short walk', time: 'Midday' },
      { title: 'Rest', time: 'Afternoon' }
    ],
    high: [
      { title: 'Medication', time: 'Morning' },
      { title: 'Exercise', time: 'Afternoon' },
      { title: 'Meal prep', time: 'Evening' }
    ]
  };
  state.schedule = schedules[energy] || [];
  if (period) {
    state.schedule.push({ title: 'Period self-care', time: 'Anytime' });
  }
  saveState(state);
  updateSchedule();
}

function togglePeriod(enabled) {
  const state = loadState();
  state.period = enabled;
  saveState(state);
  generateSchedule();
}

function addMedication() {
  const name = prompt('Medication name');
  if (!name) return;
  const time = prompt('Time (e.g., 08:00)');
  if (!time) return;
  const dose = prompt('Dose');
  if (!dose) return;
  const state = loadState();
  state.medications.push({ name, time, dose });
  saveState(state);
  updateMedications();
}

function exportData() {
  const profile = loadProfile();
  const state = loadState();
  const data = { profile, state };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'mellow_navigator_backup.json';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function importData(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const data = JSON.parse(reader.result);
      if (data.profile) {
        saveProfile(data.profile);
        renderProfile();
      }
      if (data.state) {
        localStorage.setItem('state', JSON.stringify(data.state));
        updateSchedule();
        updateMedications();
      }
    } catch (e) {
      alert('Invalid file');
    }
  };
  reader.readAsText(file);
}

function initTabs() {
  const links = document.querySelectorAll('.tab-link');
  links.forEach((link) => {
    link.addEventListener('click', () => {
      const tab = link.dataset.tab;
      document.querySelectorAll('.tab-content').forEach((c) => c.classList.add('hidden'));
      document.getElementById(tab).classList.remove('hidden');
      links.forEach((l) => l.classList.remove('active'));
      link.classList.add('active');
    });
  });
  // default active tab
  links[0].classList.add('active');
}


function init() {
  initTabs();
  renderProfile();
  updateSchedule();
  updateMedications();
  updateDocuments();
  const addDocBtn = document.getElementById('add-doc-btn');
  if (addDocBtn) { addDocBtn.addEventListener('click', addDocument); }
  // energy buttons
  document.querySelectorAll('.energy-btn').forEach((btn) => {
    btn.addEventListener('click', () => handleEnergySelection(btn.dataset.value));
  });
  // period toggle
  document.getElementById('periodToggle').addEventListener('change', (e) => togglePeriod(e.target.checked));
  // add medication
  document.getElementById('add-med-btn').addEventListener('click', addMedication);
  // export
  document.getElementById('export-btn').addEventListener('click', exportData);
  // import
  document.getElementById('import-file').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) importData(file);
  });
}

document.addEventListener('DOMContentLoaded', init);

// Document vault functions
function updateDocuments() {
  const { documents } = loadState();
  const list = document.getElementById('document-list');
  if (!list) return;
  list.innerHTML = '';
  if (!documents || documents.length === 0) {
    const empty = document.createElement('div');
    empty.textContent = 'No documents yet.';
    list.appendChild(empty);
  } else {
    documents.forEach((doc, idx) => {
      const card = document.createElement('div');
      card.className = 'card';
      const tagStr = doc.tags && doc.tags.length ? doc.tags.join(', ') : '';
      card.innerHTML = `<div class="card-title">${doc.name}</div><div>${tagStr}</div>`;
      const dlBtn = document.createElement('button');
      dlBtn.textContent = 'Download';
      dlBtn.addEventListener('click', () => {
        const link = document.createElement('a');
        link.href = doc.dataUrl;
        link.download = doc.name;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      });
      card.appendChild(dlBtn);
      list.appendChild(card);
    });
  }
}

function addDocument() {
  const fileInput = document.getElementById('doc-file');
  const tagsInput = document.getElementById('doc-tags');
  const file = fileInput ? fileInput.files[0] : null;
  const tags = tagsInput ? tagsInput.value.split(',').map((t) => t.trim()).filter(Boolean) : [];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    const state = loadState();
    if (!state.documents) state.documents = [];
    state.documents.push({ name: file.name, tags, dataUrl: reader.result, type: file.type });
    saveState(state);
  };
  reader.readAsDataURL(file);
}
